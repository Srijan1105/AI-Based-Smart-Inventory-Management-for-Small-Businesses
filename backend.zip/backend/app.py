from flask import Flask, render_template, jsonify, request
from inventory_model import forecast_sales
from pymongo import MongoClient
import json

app = Flask(__name__, static_folder='static', template_folder='templates')

client = MongoClient("mongodb://localhost:27017/")
db = client['sample_inventory']
collection = db['items']

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/data", methods=['GET'])
def get_data():
    items = list(collection.find({}, {"_id": 0}))
    return jsonify(items)

@app.route("/api/predict", methods=['POST'])
def predict():
    sales_data = request.json.get("sales_data")
    forecast = forecast_sales(sales_data)
    return jsonify(forecast)

if __name__ == "__main__":
    app.run(debug=True)
