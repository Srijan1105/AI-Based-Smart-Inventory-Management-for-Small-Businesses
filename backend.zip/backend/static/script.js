// Fetch inventory data and display in table
fetch('/api/data')
  .then(res => res.json())
  .then(data => {
    const tbody = document.getElementById('inventory-body');
    tbody.innerHTML = '';
    data.forEach(item => {
      const row = `
        <tr>
          <td>${item.name}</td>
          <td>${item.stock}</td>
          <td>${item.category || "Uncategorized"}</td>
        </tr>`;
      tbody.innerHTML += row;
    });
  });

// Load forecast chart
function loadForecastChart() {
  fetch('/api/predict', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      sales_data: [
        {"ds": "2025-07-18", "y": 60},
        {"ds": "2025-07-19", "y": 58},
        {"ds": "2025-07-20", "y": 65},
        {"ds": "2025-07-21", "y": 61},
        {"ds": "2025-07-22", "y": 70}
      ]
    })
  })
  .then(res => res.json())
  .then(forecast => {
    const labels = forecast.map(d => d.ds);
    const values = forecast.map(d => d.yhat);

    const ctx = document.getElementById("forecastChart").getContext("2d");
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{
          label: 'Predicted Sales',
          data: values,
          fill: true,
          borderColor: '#00d1b2',
          backgroundColor: 'rgba(0, 209, 178, 0.2)',
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { labels: { color: "#f1f1f1" } }
        },
        scales: {
          x: { ticks: { color: "#aaa" } },
          y: { ticks: { color: "#aaa" } }
        }
      }
    });
  });
}

loadForecastChart();
