import pandas as pd
from prophet import Prophet

def forecast_sales(data):
    df = pd.DataFrame(data)
    df.columns = ['ds', 'y']  # Prophet needs 'ds' for date and 'y' for value
    model = Prophet()
    model.fit(df)
    future = model.make_future_dataframe(periods=7)
    forecast = model.predict(future)
    return forecast[['ds', 'yhat']].tail(7).to_dict(orient='records')
